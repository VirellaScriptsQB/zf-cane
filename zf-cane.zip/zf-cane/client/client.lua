-- zf-cane/client.lua

local CANE_MODEL = `prop_cs_walking_stick`
local CANE_BONE  = 57005

-- Injured movement clipset
local INJURED_CLIPSET = 'move_m@injured'

-- Change this if your zf-notify uses a different client event name
local ZF_NOTIFY_EVENT = 'zf-notify:client:Notify'

local caneEntity = nil
local injuredActive = false
local isToggling = false

---@param message string
---@param nType string|nil  -- 'success'|'error'|'info'
local function Notify(message, nType)
    nType = nType or 'info'

    if GetResourceState('zf-notify') == 'started' then
        -- Try exports first (won't error if missing)
        local ok = pcall(function()
            if exports['zf-notify'] and exports['zf-notify'].Notify then
                exports['zf-notify']:Notify(nType, message)
                return true
            end
        end)
        if ok then return end

        ok = pcall(function()
            if exports['zf-notify'] and exports['zf-notify'].notify then
                exports['zf-notify']:notify(nType, message)
                return true
            end
        end)
        if ok then return end

        -- Fallback to a client event (you can adjust ZF_NOTIFY_EVENT above)
        pcall(function()
            TriggerEvent(ZF_NOTIFY_EVENT, nType, message)
        end)
        return
    end

    -- Safe fallback (no dependencies)
    TriggerEvent('chat:addMessage', { args = { '^3[zf-cane]^7', message } })
end

-- Server -> client notify bridge (server uses this; client uses zf-notify)
RegisterNetEvent('zf-cane:notify', function(nType, message)
    Notify(message, nType)
end)

---@param model number
---@return boolean
local function loadModel(model)
    if HasModelLoaded(model) then return true end
    RequestModel(model)

    local timeout = GetGameTimer() + 5000
    while not HasModelLoaded(model) do
        if GetGameTimer() > timeout then
            return false
        end
        Wait(0)
    end
    return true
end

---@param clipset string
---@return boolean
local function loadClipset(clipset)
    if HasAnimSetLoaded(clipset) then return true end
    RequestAnimSet(clipset)

    local timeout = GetGameTimer() + 5000
    while not HasAnimSetLoaded(clipset) do
        if GetGameTimer() > timeout then
            return false
        end
        Wait(0)
    end
    return true
end

local function applyInjuredWalk()
    if injuredActive then return end
    if not loadClipset(INJURED_CLIPSET) then
        print('[zf-cane] Failed to load clipset:', INJURED_CLIPSET)
        return
    end

    local ped = PlayerPedId()
    SetPedMovementClipset(ped, INJURED_CLIPSET, 0.25)
    injuredActive = true
end

local function clearInjuredWalk()
    if not injuredActive then return end

    local ped = PlayerPedId()
    ResetPedMovementClipset(ped, 0.25)
    ResetPedWeaponMovementClipset(ped)
    ResetPedStrafeClipset(ped)
    injuredActive = false
end

---@return boolean
local function isCaneEquipped()
    return caneEntity ~= nil and DoesEntityExist(caneEntity)
end

local function deleteCaneEntity()
    if caneEntity and DoesEntityExist(caneEntity) then
        -- Make sure we can delete it cleanly
        if not NetworkHasControlOfEntity(caneEntity) then
            NetworkRequestControlOfEntity(caneEntity)
            local timeout = GetGameTimer() + 1000
            while not NetworkHasControlOfEntity(caneEntity) and GetGameTimer() < timeout do
                Wait(0)
            end
        end

        DetachEntity(caneEntity, true, true)
        SetEntityAsMissionEntity(caneEntity, true, true)
        DeleteEntity(caneEntity)
    end
    caneEntity = nil
end

---@return boolean
local function equipCane()
    if isCaneEquipped() then
        return true
    end

    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped, false) then
        Notify('You cannot equip the canex cane in a vehicle.', 'error')
        return false
    end

    if not loadModel(CANE_MODEL) then
        Notify('Failed to load cane model.', 'error')
        return false
    end

    local coords = GetEntityCoords(ped)
    caneEntity = CreateObject(CANE_MODEL, coords.x, coords.y, coords.z, true, true, false)
    SetModelAsNoLongerNeeded(CANE_MODEL)

    AttachEntityToEntity(
        caneEntity,
        ped,
        GetPedBoneIndex(ped, CANE_BONE),
        0.10, 0.02, -0.02,
        10.0, 90.0, 180.0,
        true, true, false, true, 2, true
    )

    applyInjuredWalk()
    Notify('Cane equipped.', 'success')
    return true
end

local function unequipCane()
    -- Always clear movement even if the prop is already gone (prevents “stuck limp”)
    clearInjuredWalk()
    deleteCaneEntity()
    Notify('Cane put away.', 'info')
end

-- Safety cleanup on stop
AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    clearInjuredWalk()
    deleteCaneEntity()
end)

-- Lightweight monitor ONLY when equipped (prevents “stuck” cases)
CreateThread(function()
    while true do
        if isCaneEquipped() then
            local ped = PlayerPedId()

            -- If entity got deleted by something else, clear state + walk
            if caneEntity and not DoesEntityExist(caneEntity) then
                caneEntity = nil
                clearInjuredWalk()
            end

            -- Don’t keep limp inside vehicles; re-apply when back on foot
            if IsPedInAnyVehicle(ped, false) then
                clearInjuredWalk()
            else
                if not injuredActive then
                    applyInjuredWalk()
                end
            end

            Wait(1000)
        else
            Wait(1500)
        end
    end
end)

---@param data table ox_inventory item data
---@param slot number inventory slot
exports('cane', function(data, slot)
    if isToggling then return end
    isToggling = true

    -- Small delay to avoid double-fire from spam clicking
    SetTimeout(250, function()
        isToggling = false
    end)

    -- Toggle off immediately
    if isCaneEquipped() then
        unequipCane()
        return
    end

    -- Use ox_inventory flow (checks/verification)
    exports.ox_inventory:useItem(data, function(used)
        if not used then return end
        equipCane()
    end)
end)

-- Optional debug command
RegisterCommand('cane_debug', function()
    if isCaneEquipped() then unequipCane() else equipCane() end
end)
