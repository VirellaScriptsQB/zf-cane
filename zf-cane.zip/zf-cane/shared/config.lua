-- shared/config.lua

Config = Config or {}

---Cane settings shared by client + server.
Config.Cane = {
    itemName = 'cane',

    -- Prop
    model = `prop_cs_walking_stick`,
    bone = 57005,
    attach = {
        pos = vec3(0.10, 0.02, -0.02),
        rot = vec3(10.0, 90.0, 180.0),
    },

    -- Movement
    injuredWalk = true,
    injuredClipset = 'move_m@injured',
    blend = 0.25,

    -- Restrictions
    blockInVehicle = true,
    blockWhenDead = true,

    -- Notifications
    notify = {
        enabled = true,
        resource = 'zf-notify',

        -- If your zf-notify uses a client event, set it here:
        event = 'zf-notify:client:Notify',

        -- If your zf-notify uses exports, these are tried in order:
        exportMethods = { 'Notify', 'notify' },
    },
}
