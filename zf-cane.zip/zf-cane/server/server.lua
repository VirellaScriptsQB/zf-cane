-- zf-cane/server.lua

---Notify player via client (client forwards to zf-notify).
---@param playerId number
---@param nType 'success'|'error'|'info'
---@param message string
local function notify(playerId, nType, message)
    TriggerClientEvent('zf-cane:notify', playerId, nType, message)
end

---Server export for ox_inventory item events.
---Return false to cancel item usage.
---@param event 'usingItem'|'usedItem'|'buying'
---@param item table
---@param inventory table contains inventory.id (player server id)
---@param slot number
---@param data any
exports('cane', function(event, item, inventory, slot, data)
    if event ~= 'usingItem' then return end

    local playerId = inventory?.id
    if type(playerId) ~= 'number' then
        return false
    end

    local ped = GetPlayerPed(playerId)
    if ped == 0 then
        return false
    end

    -- Block in vehicles
    if IsPedInAnyVehicle(ped, false) then
        notify(playerId, 'error', 'You cannot use the cane in a vehicle.')
        return false
    end

    -- Block if dead
    if IsEntityDead(ped) then
        notify(playerId, 'error', 'You cannot use the cane right now.')
        return false
    end

    -- allow usage
    return
end)
